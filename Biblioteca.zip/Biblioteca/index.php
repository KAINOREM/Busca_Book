<html>
    <head>
        <title>Busca Book</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="estilo.css">
    </head>
    
    <body>
        <div class="container">
            <h1 class="page-title">Busca Book</h1>
            
            <div class="divLogin">
                    <button class="a-submit"><a href="login.php">Login</a></button>
                    <button class="a-submit"><a href="cadastrar_cliente.php">Cadastrar</a></button>
            </div>
        </div>
    </body>
</html>